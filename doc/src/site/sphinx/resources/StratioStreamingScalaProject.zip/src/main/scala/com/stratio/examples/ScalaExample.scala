/*
 * Copyright 2014, Stratio.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package com.stratio.examples

import com.stratio.streaming.api.StratioStreamingAPIFactory
import com.stratio.streaming.messaging.ColumnNameType
import java.lang._
import com.stratio.streaming.commons.constants.ColumnType
import com.stratio.streaming.commons.exceptions.StratioStreamingException
import scala.collection.JavaConversions._


object ScalaExample {
	val kafkaHost = "172.19.0.228"
	val kafkaPort = 9092
	val zookeeperHost = "172.19.0.228"
	val zookeeperPort = 2181
  
	def main(args : Array[String]) {
	  
	  try {
		  val stratioStreamingAPI = StratioStreamingAPIFactory.create().initializeWithServerConfig(kafkaHost, 
					kafkaPort, 
					zookeeperHost, 
					zookeeperPort)
		  val firstStreamColumn = new ColumnNameType("column1", ColumnType.INTEGER)
		  val secondStreamColumn = new ColumnNameType("column2", ColumnType.STRING)
		  val streamName = "testStream"
		  val columnList = Seq(firstStreamColumn, secondStreamColumn)
         
		  stratioStreamingAPI.createStream(streamName, columnList)
            val listOfStreams = stratioStreamingAPI.listStreams().toList
            println("Number of streams: "+listOfStreams.size)
		  listOfStreams.foreach(stream => {
			  println("--> Stream name: "+stream.getStreamName)
			  if (stream.getQueries.size>0) {
				  stream.getQueries.foreach(query =>
				  println("Query: "+query.getQuery))
			  }
		  })
    } catch {
      case ssEx: StratioStreamingException => println(ssEx.printStackTrace())
    }
  }
}
