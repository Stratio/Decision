/*
 * Copyright 2014, Stratio.
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.stratio.examples;

import java.util.Arrays;
import java.util.List;

import com.stratio.streaming.api.IStratioStreamingAPI;
import com.stratio.streaming.api.StratioStreamingAPIFactory;
import com.stratio.streaming.commons.constants.ColumnType;
import com.stratio.streaming.commons.exceptions.StratioStreamingException;
import com.stratio.streaming.commons.streams.StratioStream;
import com.stratio.streaming.messaging.ColumnNameType;

public class JavaExample 
{
	public final static String KAFKA_HOST = "172.19.0.228";
	public final static int KAFKA_PORT = 9092;
	public final static String ZOOKEEPER_HOST = "172.19.0.228";
	public final static int ZOOKEEPER_PORT = 2181;
	
    public static void main( String[] args )
    {
    	IStratioStreamingAPI stratioStreamingAPI;
		
    	try {
    		stratioStreamingAPI = StratioStreamingAPIFactory.create().initializeWithServerConfig(KAFKA_HOST, 
					KAFKA_PORT, 
					ZOOKEEPER_HOST, 
					ZOOKEEPER_PORT);
		  	ColumnNameType firstStreamColumn= new ColumnNameType("column1", ColumnType.INTEGER);
	    	ColumnNameType secondStreamColumn = new ColumnNameType("column2", ColumnType.STRING);
	    	String streamName = "testStream";
	        List<ColumnNameType> columnList = Arrays.asList(firstStreamColumn, secondStreamColumn);
	        
	        	//CREATE STREAM
				stratioStreamingAPI.createStream(streamName, columnList);
			  	List<StratioStream> streamsList = stratioStreamingAPI.listStreams();
			  	System.out.println("Streams in the Stratio Streaming Engine: " + streamsList.size());
			  	for (StratioStream stream: streamsList) 
			  		System.out.println("-- Stream Name: "+stream.getStreamName());
        } catch (StratioStreamingException e) {
			e.printStackTrace();
		}
    	
        System.exit(0);
    }
}
